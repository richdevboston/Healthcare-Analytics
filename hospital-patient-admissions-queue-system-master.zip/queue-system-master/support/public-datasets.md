
## Links of Health related datasets

Here are sources for some (publicly available) datasets that may have something relevant to what we are looking for.

- health datasets from NYC open data:
    - [https://nycopendata.socrata.com/data?browseSearch=&scope=&agency=&cat=health&type=datasets](https://nycopendata.socrata.com/data?browseSearch=&scope=&agency=&cat=health&type=datasets)

- large health datasets:
    - [http://www.ehdp.com/vitalnet/datasets.htm](http://www.ehdp.com/vitalnet/datasets.htm)

- healthData.gov
    - [http://hub.healthdata.gov/dataset](http://hub.healthdata.gov/dataset)

- healthcare
    - [http://hcupnet.ahrq.gov](http://hcupnet.ahrq.gov)

- health care databases:
    - [http://www.hcup-us.ahrq.gov](http://www.hcup-us.ahrq.gov)

- len of stay
    - [http://www.hcup-us.ahrq.gov/sidoverview.jsp#data](http://www.hcup-us.ahrq.gov/sidoverview.jsp#data)
